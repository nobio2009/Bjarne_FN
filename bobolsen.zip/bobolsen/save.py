saved_point = 7
saved_upgrade = 1
saved_trash_max = 2
